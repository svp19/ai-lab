# GOAL STATE PLANNING (Blocks World Domain)

Source code in `src`.
Report - `report.pdf`.
Input/Output files in `testcases`.

## Steps to Run

`./run.sh <path-to-input-file> <path-to-output-file(optional)>`

Example -

`./run.sh testcases/input1.txt testcases/output1.txt`
