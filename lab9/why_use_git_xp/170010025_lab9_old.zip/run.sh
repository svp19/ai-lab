python3 src/main.py $1 $2
