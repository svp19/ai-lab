#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" 
    Defines actions for the HIGH LOW card game.
"""

LOW = 0
HIGH = 1